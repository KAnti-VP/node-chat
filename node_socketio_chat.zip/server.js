
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.static('public'));

let users = {};
let rooms = {};
let messages = {};

io.on('connection', (socket) => {
    console.log('User connected:', socket.id);

    socket.on('setUsername', (username) => {
        users[socket.id] = username;
        io.emit('userList', Object.values(users));

        socket.on('createPrivateRoom', (otherUser) => {
            const user = users[socket.id];
            const room = createPrivateRoom(user, otherUser);

            socket.join(room);
            const otherSocket = Object.entries(users).find(([id, name]) => name === otherUser)?.[0];
            if (otherSocket) {
                io.to(otherSocket).emit('chatHistory', { room, messages: messages[room] });
                io.sockets.sockets.get(otherSocket).join(room);
            }
            socket.emit('chatHistory', { room, messages: messages[room] });
        });

        socket.on('message', ({ room, message }) => {
            const user = users[socket.id];
            const msg = { sender: user, message, timestamp: new Date().toLocaleTimeString() };
            messages[room].push(msg);
            io.to(room).emit('newMessage', msg);
        });
    });

    socket.on('disconnect', () => {
        delete users[socket.id];
        io.emit('userList', Object.values(users));
    });
});

function createPrivateRoom(user1, user2) {
    const roomName = [user1, user2].sort().join('-');
    if (!rooms[roomName]) {
        rooms[roomName] = { type: 'private', users: new Set([user1, user2]) };
        messages[roomName] = [];
    }
    return roomName;
}

server.listen(3000, () => {
    console.log('Server running on http://localhost:3000');
});
